const Farm = require('../models/Farm');

module.exports = {

    addFarm: async (req, res) => {
        const {title, time, imageUrl, owner, code, logoUrl, coords} = req.body;
        if(!title || !time || !imageUrl || !owner || !code || !logoUrl || !coords 
            || !coords.latitude || !coords.longitude || !coords.address || !coords.title) {
            return res.status(400).json({status: false, message: 'You have a missing field'});
            }

        try {
            const newfarm = new Farm(req.body);

            await newfarm.save();
            res.status(201).json({status: true, message: 'Farm has been successfully created'});
        } catch (error) {
            res.status(500).json({status: false, message: error.message});
    }
    },
    getFarmById: async (req, res) => {
        const id = req.params.id;
        try {
            const farm = await Farm.findById(id);
            res.status(200).json(farm);
        } catch (error) {
            res.status(500).json({status: false, message: error.message});
        }

    },
    getRandomFarms: async (req, res) => {
        const code = req.params.code;
        try {
            let getRandomFarms = [];

            if(code) {
                randomFarm = await Farm.aggregate([
                    {$match: {code: code, isAvailable: true}},
                    {$sample: {size: 5}},
                    {$project: {_v: 0}}
                ]);
            }

            if(randomFarm.length === 0) {
                randomFarm = await Farm.aggregate([
                    {$match: {isAvailable: true}},
                    {$sample: {size: 5}},
                    {$project: {_v: 0}}
                ]);
            }
            res.status(200).json(randomFarm);
        } catch (error) {
            res.status(500).json({status: false, message: error.message});
        }
    },
    getAllNearByFarms: async (req, res) => {
        const code = req.params.code;
        try {
            let allNearByFarm = [];

            if(code) {
                allNearByFarm = await Farm.aggregate([
                    {$match: {code: code, isAvailable: true}},
                    {$project: {_v: 0}}
                ]);
            }

            if(allNearByFarm.length === 0) {
                allNearByFarm = await Farm.aggregate([
                    {$match: {isAvailable: true}},
                    {$project: {_v: 0}}
                ]);
            }
            res.status(200).json(allNearByFarm);
        } catch (error) {
            res.status(500).json({status: false, message: error.message});
        }
    },
}