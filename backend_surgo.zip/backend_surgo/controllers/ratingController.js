const Rating = require('../models/Rating')
const Farm = require('../models/Farm');
const Product = require('../models/Product');
const Driver = require('../models/Driver');
module.exports = {
    addRating: async (req, res) => {
        const newRating = new Rating({
            userId: req.user.id,
            ratingType: req.body.ratingType,
            product: req.body.product,
            rating: req.body.rating
        });
    
        try {
             await newRating.save();
    
            if (req.body.ratingType === 'Farm') {
                const farms = await Rating.aggregate([
                    { $match: { ratingType: 'Farm', product: req.body.product } },
                    { $group: { _id: '$product', averageRating: { $avg: '$rating' } } }
                ]);
    
                if (farms.length > 0) {
                    const averageRating = farms[0].averageRating;
                    await Farm.findByIdAndUpdate(req.body.product, { rating: averageRating }, { new: true });
                }
            } else if (req.body.ratingType === 'Driver') {
                const driver = await Rating.aggregate([
                    { $match: { ratingType: 'Driver', product: req.body.product } },
                    { $group: { _id: '$product', averageRating: { $avg: '$rating' } } }
                ]);
    
                if (driver.length > 0) {
                    const averageRating = driver[0].averageRating;
                    await Driver.findByIdAndUpdate(req.body.product, { rating: averageRating }, { new: true });
                }
            } else if (req.body.ratingType === 'Product') {
                const product = await Rating.aggregate([
                    { $match: { ratingType: 'Product', product: req.body.product } },
                    { $group: { _id: '$product', averageRating: { $avg: '$rating' } } }
                ]);
    
                if (product.length > 0) {
                    const averageRating = product[0].averageRating;
                    await Product.findByIdAndUpdate(req.body.product, { rating: averageRating }, { new: true });
                }
            }
    
            res.status(200).json({status: true, message: 'Rating added successfully'});
        } catch (error) {
            res.status(500).json({status: false, message: error.message});
        }
    },


     checkIfUserRatedFarm: async (req, res) => {
        const ratingType = req.query.ratingType;
        const product = req.query.product;

        try {
            const ratingExists = await Rating.findOne({
                userId: req.user.id,
                product: product,
                ratingType: ratingType
            });
    
            if (ratingExists) {
                return res.status(200).json({ status: true, message: "You have already rated this farm." });
            } else {
                return res.status(200).json({ status: false, message: "User has not rated this farm yet." });
            }
        } catch (error) {
            return res.status(500).json({ status: false, message: error.message });
        }
    }
}