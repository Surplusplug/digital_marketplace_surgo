const Product = require('../models/Product');


module.exports = {
    addProduct: async (req, res) => {
        const { title, productTags, category, productType, code, isAvailable, farm, description,time, price, additives, imageUrl } = req.body;

        // Simple validation
        if (!title || !productTags || !category || !productType || !code || !description || !price || !additives || !time || !imageUrl || !farm || !isAvailable) {
            return res.status(400).json({ status: false, message: 'Missing required fields' });
        }

        try {
        const newProduct = new Product({
            title: req.body.title,
            productTags: req.body.productTags,
            category: req.body.category,
            productType: req.body.productType,
            code: req.body.code,
            isAvailable: req.body.isAvailable,
            farm: req.body.farm,
            description: req.body.description,
            time: req.body.time,
            price: req.body.price,
            additives: req.body.additives,
            imageUrl: req.body.imageUrl
        });
    
        
            await newProduct.save();
            res.status(201).json({ status: true, message: 'Product item successfully created', data: newProduct });
        } catch (error) {
            res.status(500).json({ status: false, message: error.message });
        }
    },

    getProductById: async (req, res) => {
        const productId = req.params.id;
    
        try {
            // Fetch product by ID and select specific fields you want to return
            const product = await Product.findById(productId).select(
                'title productTags productType code isAvailable farm rating ratingCount description price additives imageUrl category time, createdAt, updatedAt'
            );
    
            // If product item is not found
            if (!product) {
                return res.status(404).json({ status: false, message: 'Product item not found' });
            }
            console.log(product);
            // Send back the product item
            res.status(200).json({
                ...product._doc,
                farm: product.farm.toString(),
                category: product.category.toString(),
                ratingCount:product.ratingCount.toString(),
                rating:parseFloat(product.rating)
              });
              
              
        } catch (error) {
            // Send error response
            res.status(500).json({ status: false, message: 'An error occurred while fetching the product item.' });
        }
    },
    
    getProductList: async (req, res) => {
        const farm = req.params.id;
      
        try {
          const products = await Product.find({ farm: farm }).sort({ createdAt: -1 }); // Sort by date in descending order (newest first)
      
          res.status(200).json(products);
        } catch (error) {
          res.status(500).json({ status: false, message: error.message });
        }
      },
      
      deleteProductById: async (req, res) => {
        const productId = req.params.id;

        try {
            const product = await Product.findByIdAndDelete(productId);

            if (!product) {
                return res.status(404).json({ status: false, message: 'Product item not found' });
            }

            res.status(200).json({ status: true, message: 'Product item successfully deleted' });
        } catch (error) {
            res.status(500).json(error);
        }
    },

    productAvailability: async (req, res) => {
        const productId = req.params.id;

        try {
            // Find the farm by its ID
            const product = await Product.findById(productId);

            if (!farm) {
                return res.status(404).json({ message: 'Product not found' });
            }

            // Toggle the isAvailable field
            product.isAvailable = !product.isAvailable;

            // Save the changes
            await product.save();

            res.status(200).json({ message: 'Availability toggled successfully' });
        } catch (error) {
            res.status(500).json(error);
        }
    },

    updateProductById: async (req, res) => {
        const productId = req.params.id;

        try {
            const updatedProduct = await Product.findByIdAndUpdate(productId, req.body, { new: true, runValidators: true });

            if (!updatedProduct) {
                return res.status(404).json({ status: false, message: 'Product item not found' });
            }

            res.status(200).json({ status: true, message: 'Product item successfully updated' });
        } catch (error) {
            res.status(500).json(error);
        }
    },

    addProductTag: async (req, res) => {
        const productId = req.params.id;
        const { tag } = req.body;  // Assuming the tag to be added is sent in the request body

        if (!tag) {
            return res.status(400).json({ status: false, message: 'Tag is required' });
        }

        try {
            const product = await Product.findById(productId);

            if (product) {
                return res.status(404).json({ status: false, message: 'Product item not found' });
            }

            // Check if tag already exists
            if (product.productTags.includes(tag)) {
                return res.status(400).json({ status: false, message: 'Tag already exists' });
            }

            product.productTags.push(tag);
            await product.save();

            res.status(200).json({ status: true, message: 'Tag successfully added', data: product });
        } catch (error) {
            res.status(500).json(error);
        }
    },


    getRandomProductsByCode: async (req, res) => {
        try {
            let randomProductList = [];
    
            // Check if code is provided in the params
            if (req.params.code) {
                randomProductList = await Product.aggregate([
                    { $match: { code: req.params.code } },
                    { $sample: { size: 3 } },
                    { $project: {  __v: 0 } }
                ]);
            }
            
            // If no code provided in params or no Products match the provided code
            if (!randomProductList.length) {
                randomProductList = await Product.aggregate([
                    { $sample: { size: 5 } },
                    { $project: {  __v: 0 } }
                ]);
            }
    
            // Respond with the results
            if (randomProductList.length) {
                res.status(200).json(randomProductList);
            } else {
                res.status(404).json({status: false, message: 'No Products found' });
            }
        } catch (error) {
            res.status(500).json(error);
        }
    },


    addProductType: async (req, res) => {
        const productId = req.params.id;
        const { productType } = req.body.productType;  // Assuming the tag to be added is sent in the request body


        try {
            const product = await Product.findById(productId);

            if (product) {
                return res.status(404).json({ status: false, message: 'Product item not found' });
            }

            // Check if tag already exists
            if (product.productType.includes(productType)) {
                return res.status(400).json({ status: false, message: 'Type already exists' });
            }

            product.productType.push(productType);
            await product.save();

            res.status(200).json({ status: true, message: 'Type successfully added' });
        } catch (error) {
            res.status(500).json(error);
        }
    },

    getRandomProductsByCategoryAndCode: async (req, res) => {
        const { category, code } = req.params;  // Assuming category, code, and value are sent as parameters

        try {
            let products = await Product.aggregate([
                { $match: { category: category } },
                { $sample: { size: 10 } }
            ]);

            if (!products || products.length === 0) {
                products = await Product.aggregate([
                    { $match: { code: code } },
                    { $sample: { size: 10 } }
                ]);
            } else {
                products = await Product.aggregate([
                    { $sample: { size: 10 } }
                ]);
            }

            res.status(200).json(products);
        } catch (error) {
            res.status(500).json({ error: error.message, status: false });
        }
    },

    getProductsByCategoryAndCode: async (req, res) => {
        const { category, code } = req.params;  // Assuming category, code, and value are sent as parameters
        try {
            const products = await Product.aggregate([
                { $match: { category: category } },
            ]);

            if(products.length === 0){
                return res.status(200).json([])
            }

            res.status(200).json(products);
        } catch (error) {
            res.status(500).json({ error: error.message, status: false });
        }
    },

    searchProducts: async (req, res) => {
        const search = req.params.product
        try {
            const results = await Product.aggregate(
                [
                    {
                        $search: {
                            index: "products",
                            text: {
                                query: search,
                                path: {
                                    wildcard: "*"
                                }
                            }
                        }
                    }
                ]
            )
            res.status(200).json(results);
        } catch (error) {
            res.status(500).json({ error: error.message, status: false });
        }
    },
    getAllPromotionalProducts: async (req, res) => {
        try {
            // Get all products where promotion is true
            const promotionalProducts = await Product.find({ promotion: true, verified:true }).select('-__v');
            
            // Respond with the results
            if (promotionalProducts.length) {
                res.status(200).json(promotionalProducts);
            } else {
                res.status(200).json(promotionalProducts);
                //res.status(404).json({ status: false, message: 'No promotional products found' });
            }
        } catch (error) {
            res.status(500).json(error);
        }
    },    

}