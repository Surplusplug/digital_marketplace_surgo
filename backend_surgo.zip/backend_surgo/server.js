const express = require('express')
const app = express()
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const CategoryRoute = require('./routes/category');
const FarmRoute = require('./routes/farm');
const ProductRoute = require('./routes/product');
const RatingRoute = require('./routes/rating');
const generateOtp = require('./utils/otp_generator');
const sendEmail = require('./utils/email_verification');
const UserRoute = require('./routes/user');


require('dotenv').config();


mongoose.connect(process.env.MONGO_URI)
.then(() => console.log('Surgo Database Connected!'))
.catch((err) => console.log(err));

// const otp = generateOtp();
// console.log(otp); //used to test otp
// sendEmail('surplusplug1@gmail.com', otp)

app.get('/', (req, res) => res.send('Hello World!'))

app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.use('/api/category', CategoryRoute);
app.use('/api/farm', FarmRoute);
app.use('/api/product', ProductRoute);
app.use('/api/rating', RatingRoute);


app.listen(process.env.PORT || 6013, () => console.log(`Surgo Backend is running on ${process.env.PORT}!`))