const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
    title: { type: String, required: true },
    time: { type: String, required: true },
    productTags: { type: Array, required: true },
    category: { type: String, required: true },
    productType: { type: Array, required: true },
    code: { type: String, required: true },
    isAvailable: { type: Boolean, required: true, default: true },
    farm: { type: mongoose.Schema.Types.ObjectId, ref: "Farm" },
    rating: {
        type: Number,
        min: 1,
        max: 5,
        default: 3
    },
    ratingCount: { type: String, default: "302" },
    description: { type: String, required: true },
    price: { type: Number, required: true },
    additives: { type: Array, required: true },
    imageUrl: { type: Array, required: true },
    // promotion: { type: Boolean, required: false },
    // promotionPrice: { type: Number, required: true, default: 0.0 },
}, {
    timestamps: true  // Automatically adds createdAt and updatedAt
});

module.exports = mongoose.model('Product', ProductSchema);