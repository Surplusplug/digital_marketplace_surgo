const jwt = require("jsonwebtoken");
const User = require("../models/User");

// Verify Token Middleware
const verifyToken = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).json({ status: false, message: "You are not authenticated" });
    }

    const token = authHeader.split(" ")[1];
    jwt.verify(token, process.env.JWT_SEC, (err, user) => {
        if (err) {
            return res.status(403).json({ status: false, message: "Invalid token" });
        }
        req.user = user;
        next();
    });
};

// Verify Authorization Middleware
const verifyTokenAndAuthorization = (req, res, next) => {
    verifyToken(req, res, () => {
        const allowedRoles = ['Client', 'Driver', 'Vendor', 'Admin'];
        if (req.user && allowedRoles.includes(req.user.userType)) {
            next();
        } else {
            res.status(403).json({ status: false, message: "You are restricted from performing this operation" });
        }
    });
};

// Verify Vendor Middleware
const verifyVendor = (req, res, next) => {
    verifyToken(req, res, () => {
        if (req.user && (req.user.userType === "Vendor" || req.user.userType === "Admin")) {
            next();
        } else {
            res.status(403).json({ status: false, message: "You have limited access" });
        }
    });
};

// Verify Driver Middleware
const verifyDriver = (req, res, next) => {
    verifyToken(req, res, () => {
        if (req.user && (req.user.userType === "Driver" || req.user.userType === "Admin")) {
            next();
        } else {
            res.status(403).json({ status: false, message: "You are restricted from performing this operation" });
        }
    });
};

// Verify Admin Middleware
const verifyAdmin = (req, res, next) => {
    verifyToken(req, res, () => {
        if (req.user && req.user.userType === "Admin") {
            next();
        } else {
            res.status(403).json({ status: false, message: "You are restricted from performing this operation" });
        }
    });
};

module.exports = { verifyToken, verifyTokenAndAuthorization, verifyVendor, verifyDriver, verifyAdmin };
