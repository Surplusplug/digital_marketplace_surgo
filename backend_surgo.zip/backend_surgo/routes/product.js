const router = require("express").Router();
const productController = require("../controllers/productController");
const {verifyTokenAndAuthorization, verifyVendor}= require("../middleware/verifyToken")


// UPADATE category
router.get("/", productController.addProduct)
router.get('/farm-products/:id', productController.getProductList)
router.get('/promotional-products', productController.getAllPromotionalProducts)
router.post("/", verifyVendor , productController.addProduct);

router.post("/tags/:id", productController.addProductTag);

router.post("/type/:id", productController.addProductType);

router.get("/:id", productController.getProductById);
router.get("/search/:product", productController.searchProducts);

router.get("/categories/:category/:code", productController.getProductsByCategoryAndCode);
router.get("/:category/:code", productController.getRandomProductsByCategoryAndCode);

router.delete("/:id", productController.deleteProductById);

router.patch("/:id", productController.productAvailability);

router.get("/recommendation/:code", productController.getRandomProductsByCode);





module.exports = router