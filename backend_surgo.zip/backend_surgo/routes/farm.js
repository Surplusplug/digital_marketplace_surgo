const router = require('express').Router();
const farmController = require('../controllers/farmController');

router.post('/', farmController.addFarm);

router.get('/:code', farmController.getRandomFarms);

router.get('/all/:code', farmController.getAllNearByFarms);

router.get('/byId/:id', farmController.getFarmById);

module.exports = router;