package com.example.surgo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
